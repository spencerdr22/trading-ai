"""
Package: app.utils
Part of the trading-ai project.
"""

__version__ = "0.1.0"
