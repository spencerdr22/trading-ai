"""
Root package for the trading-ai project.
"""

__version__ = "0.1.0"
