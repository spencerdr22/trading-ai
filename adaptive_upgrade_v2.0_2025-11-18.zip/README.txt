Trading-AI Adaptive Upgrade v2.0 (2025-11-18)

=========================================================

1. Extract this ZIP directly into your repository root (`trading-ai/`).

2. Open VS Code.  Run `git diff` or use Source Control to review changes.

3. Commit merged files with message: "Upgrade → Adaptive RL Framework v2.0".

4. (Optional) Re-run `python generate_code_changes.py --apply` to confirm integrity.

5. Enjoy your new self-learning Trading-AI system!

=========================================================

