Trading-AI Adaptive Upgrade v2.0 (2025-11-18)

===========================================================

1. Extract this ZIP directly into your repository root (`trading-ai/`).

2. Open VS Code. Use Git diff or Source Control to review new files.

3. Commit merged changes with message: "Upgrade → Adaptive RL Framework v2.0".

4. Run `python generate_code_changes.py --apply` to confirm integrity.

5. Launch offline retraining: `python -m app.adaptive.run_offline_rl --episodes 10 --tune`

6. Enjoy your self-improving adaptive trading AI!

===========================================================

