"""
Utility for controlled repository patching and maintenance.
Supports --dry-run and --apply. Generates patch diffs and backups.
"""

import os, difflib, argparse
from datetime import datetime

LOG_DIR="data/logs"; PATCH_DIR="data/patches"
os.makedirs(LOG_DIR,exist_ok=True); os.makedirs(PATCH_DIR,exist_ok=True)
LOG_PATH=os.path.join(LOG_DIR,"code_changes.log")

def log(msg):
    ts=datetime.now().strftime("[%Y-%m-%d %H:%M:%S] ")
    with open(LOG_PATH,"a",encoding="utf-8") as f: f.write(ts+msg+"\n")
    print(msg)

def backup_file(path):
    if not os.path.exists(path): return
    ts=datetime.now().strftime("%Y%m%d_%H%M%S")
    backup=os.path.join(PATCH_DIR,f"{os.path.basename(path)}_{ts}.bak")
    with open(path,"r",encoding="utf-8") as s, open(backup,"w",encoding="utf-8") as d: d.write(s.read())
    log(f"[BACKUP] {path} → {backup}")

def create_patch(orig,new,name):
    diff=list(difflib.unified_diff(orig.splitlines(True),new.splitlines(True),fromfile=name+"_old",tofile=name+"_new"))
    patch=os.path.join(PATCH_DIR,name.replace("/","_")+".patch")
    with open(patch,"w",encoding="utf-8") as f: f.writelines(diff)
    log(f"[PATCH] {patch}")

def write_file(path,content,apply=False):
    if not apply: log(f"[DRY] Would update: {path}"); return
    os.makedirs(os.path.dirname(path),exist_ok=True); backup_file(path)
    with open(path,"w",encoding="utf-8") as f: f.write(content.strip()+"\n")
    log(f"[WRITE] {path}")

def main():
    p=argparse.ArgumentParser(); p.add_argument("--dry-run",action="store_true"); p.add_argument("--apply",action="store_true")
    a=p.parse_args(); apply=a.apply
    log("=== CODE UPDATE START ===")
    targets=["app/adaptive/model_hub.py","app/adaptive/reward.py","app/adaptive/learner.py",
             "app/adaptive/optimizer.py","app/adaptive/run_offline_rl.py",
             "app/ml/trainer.py","app/strategy/engine.py"]
    for t in targets:
        if not os.path.exists(t): log(f"[MISSING] {t}"); continue
        with open(t,"r",encoding="utf-8") as f: old=f.read()
        create_patch(old,old,t)
        if apply: write_file(t,old,apply=True)
    log("=== CODE UPDATE COMPLETE ===")

if __name__=="__main__": main()
