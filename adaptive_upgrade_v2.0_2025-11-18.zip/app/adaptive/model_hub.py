"""
Module: model_hub.py
Author: Adaptive Framework Generator

Description:
    Centralized persistence and version management for all ML models:
        - Supervised models (RF, LSTM, Hybrid)
        - RL policies (PyTorch)
        - Hyperparameter metadata
    Uses SQLite through SQLAlchemy ORM for tracking versions, metrics,
    timestamps, and model metadata.
"""

import os
import json
import torch
import joblib
from datetime import datetime
from sqlalchemy import Table, Column, Integer, String, DateTime, JSON, MetaData
from sqlalchemy.orm import Session
from ..db.init import get_engine
from ..monitor.logger import get_logger

logger = get_logger(__name__)
MODEL_DIR = "data/models"
os.makedirs(MODEL_DIR, exist_ok=True)

engine = get_engine()
metadata = MetaData()

model_registry = Table(
    "model_registry",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("model_name", String),
    Column("model_type", String),
    Column("version", Integer),
    Column("timestamp", DateTime),
    Column("metrics", JSON),
    Column("file_path", String),
)
metadata.create_all(engine)

class ModelHub:
    def __init__(self):
        self.engine = engine

    def _get_latest_version(self, model_name, model_type):
        with Session(self.engine) as session:
            rows = (
                session.query(model_registry)
                .filter(model_registry.c.model_name == model_name)
                .filter(model_registry.c.model_type == model_type)
                .order_by(model_registry.c.version.desc())
                .all()
            )
        return rows[0].version if rows else 0

    def _next_version(self, model_name, model_type):
        return self._get_latest_version(model_name, model_type) + 1

    def save_model(self, model, model_name, model_type, metrics=None):
        version = self._next_version(model_name, model_type)
        timestamp = datetime.utcnow()
        if model_type in ("RLPolicy", "LSTM", "Hybrid"):
            file_path = os.path.join(MODEL_DIR, f"{model_name}_v{version}.pt")
            torch.save(model.state_dict() if hasattr(model, "state_dict") else model, file_path)
        elif model_type in ("RF", "Metadata"):
            file_path = os.path.join(MODEL_DIR, f"{model_name}_v{version}.pkl")
            joblib.dump(model, file_path)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")
        with Session(self.engine) as session:
            session.execute(
                model_registry.insert(),
                {
                    "model_name": model_name,
                    "model_type": model_type,
                    "version": version,
                    "timestamp": timestamp,
                    "metrics": metrics or {},
                    "file_path": file_path,
                }
            )
            session.commit()
        return file_path

    def load_model(self, model_name, model_type):
        latest_version = self._get_latest_version(model_name, model_type)
        if latest_version == 0:
            logger.warning(f"No model found for {model_name} type={model_type}")
            return None
        with Session(self.engine) as session:
            row = (
                session.query(model_registry)
                .filter(model_registry.c.model_name == model_name)
                .filter(model_registry.c.model_type == model_type)
                .filter(model_registry.c.version == latest_version)
                .first()
            )
        if not row:
            return None
        file_path = row.file_path
        if not os.path.exists(file_path):
            logger.error(f"Model file missing: {file_path}")
            return None
        if model_type in ("RF", "Metadata"):
            return joblib.load(file_path)
        if model_type in ("RLPolicy", "LSTM", "Hybrid"):
            state = torch.load(file_path, map_location=torch.device("cpu"))
            return state
        logger.error(f"Unknown model_type for load: {model_type}")
        return None
