"""
Module: reward.py
Computes reward signals for RL using Sharpe, Sortino, drawdown penalties.
"""

import numpy as np

def _safe(val, eps=1e-9):
    return val if abs(val) > eps else eps

def compute_sharpe(pnl_series):
    r = np.asarray(pnl_series, dtype=float)
    if len(r) < 2: return 0.0
    return float(np.mean(r) / _safe(np.std(r)))

def compute_sortino(pnl_series):
    r = np.asarray(pnl_series, dtype=float)
    if len(r) < 2: return 0.0
    downside = np.std([x for x in r if x < 0]) or 1e-9
    return float(np.mean(r) / downside)

def compute_drawdown(pnl_series):
    r = np.asarray(pnl_series, dtype=float)
    if r.size < 2: return 0.0
    cum = np.cumsum(r)
    peaks = np.maximum.accumulate(cum)
    dd = cum - peaks
    return float(abs(np.min(dd)))

def compute_reward(pnl_series, win_rate, leverage_factor=1.0,
                   pnl_weight=0.5, sharpe_weight=0.2, sortino_weight=0.2,
                   dd_penalty_weight=0.3, win_rate_weight=0.4):
    pnl_series = np.asarray(pnl_series, dtype=float)
    total_pnl = float(np.sum(pnl_series))
    sharpe = compute_sharpe(pnl_series)
    sortino = compute_sortino(pnl_series)
    drawdown = compute_drawdown(pnl_series)
    reward = (
        (total_pnl * pnl_weight)
        + (sharpe * sharpe_weight)
        + (sortino * sortino_weight)
        + (win_rate * win_rate_weight)
        - (drawdown * dd_penalty_weight)
        - (abs(leverage_factor - 1.0) * 0.1)
    )
    return float(np.clip(reward, -10.0, 10.0))

def compute_batch_reward(trade_pnls, win_rate):
    return compute_reward(trade_pnls, win_rate)
