"""
Module: optimizer.py
Optuna-driven Bayesian hyperparameter optimization for RL subsystem.
"""

import optuna, numpy as np, torch
import torch.nn as nn, torch.optim as optim
from torch.distributions import Categorical
from sqlalchemy.orm import Session
from ..db.init import get_engine
from ..db.schema import TradeMetric
from ..monitor.logger import get_logger
from .reward import compute_batch_reward
from .model_hub import ModelHub

logger=get_logger(__name__)

class RLHyperOptimizer:
    def __init__(self,feature_dim=4,model_name="adaptive_policy"):
        self.feature_dim=feature_dim; self.engine=get_engine(); self.hub=ModelHub(); self.model_name=model_name

    def _objective(self,trial):
        lr=trial.suggest_float("lr",1e-5,5e-4,log=True)
        gamma=trial.suggest_float("gamma",0.90,0.999)
        pnl_w=trial.suggest_float("pnl_weight",0.3,0.7)
        sharpe_w=trial.suggest_float("sharpe_weight",0.1,0.4)
        sortino_w=trial.suggest_float("sortino_weight",0.1,0.4)
        dd_w=trial.suggest_float("dd_penalty_weight",0.2,0.5)

        policy=nn.Sequential(nn.Linear(self.feature_dim,128),nn.ReLU(),
                             nn.Linear(128,64),nn.ReLU(),
                             nn.Linear(64,3),nn.Softmax(dim=-1))
        opt=optim.Adam(policy.parameters(),lr=lr)
        with Session(self.engine) as s: rows=s.query(TradeMetric).all()
        if len(rows)<20: return -9999
        pnls=[float(r.pnl) for r in rows]
        wins=sum(1 for r in rows if r.pnl>0); win_rate=wins/len(rows)
        reward=compute_batch_reward(pnls,win_rate)
        state=torch.tensor([float(np.mean(pnls)),float(np.std(pnls)),win_rate,reward],
                           dtype=torch.float32).unsqueeze(0)
        probs=policy(state); dist=Categorical(probs); a=dist.sample()
        loss=-dist.log_prob(a)*reward; opt.zero_grad(); loss.backward(); opt.step()
        return float(reward-loss.item())

    def optimize(self,n_trials=5):
        study=optuna.create_study(direction="maximize")
        study.optimize(self._objective,n_trials=n_trials)
        best=study.best_params; score=float(study.best_value)
        self.hub.save_model({},f"{self.model_name}_hyperparams","Metadata",
            metrics={"params":best,"score":score})
        logger.info(f"Optuna best params {best}, score={score:.4f}")
        return best,score
