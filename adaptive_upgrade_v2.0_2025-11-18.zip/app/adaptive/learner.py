"""
Module: learner.py
Offline reinforcement-learning engine for the adaptive trading system.
Implements REINFORCE with PyTorch and integrates ModelHub persistence.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
from sqlalchemy.orm import Session
from ..db.init import get_engine
from ..db.schema import TradeMetric
from ..monitor.logger import get_logger
from .reward import compute_batch_reward
from .model_hub import ModelHub

logger = get_logger(__name__)

class PolicyNet(nn.Module):
    def __init__(self, feature_dim=4, n_actions=3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feature_dim,128), nn.ReLU(),
            nn.Linear(128,64), nn.ReLU(),
            nn.Linear(64,n_actions), nn.Softmax(dim=-1)
        )
    def forward(self,x): return self.net(x)

class ReinforcementLearner:
    def __init__(self, feature_dim=4, lr=1e-4, gamma=0.99, model_name="adaptive_policy"):
        self.feature_dim=feature_dim; self.gamma=gamma; self.model_name=model_name
        self.policy=PolicyNet(feature_dim)
        self.optimizer=optim.Adam(self.policy.parameters(), lr=lr)
        self.hub=ModelHub(); self.engine=get_engine()
        logger.info(f"RL Learner init (dim={feature_dim}, lr={lr}, gamma={gamma})")

    def save_policy(self,reward=None):
        metrics={"reward":reward}
        self.hub.save_model(self.policy,self.model_name,"RLPolicy",metrics)
        logger.info(f"RL policy saved (reward={reward})")

    def load_latest_policy(self):
        state=self.hub.load_model(self.model_name,"RLPolicy")
        if state: self.policy.load_state_dict(state); logger.info("Loaded latest RL policy.")
        else: logger.warning("No existing RL policy found.")

    def update_policy(self,log_probs,reward):
        loss=torch.stack([-lp*reward for lp in log_probs]).sum()
        self.optimizer.zero_grad(); loss.backward(); self.optimizer.step()
        return float(loss.item())

    def train_from_history(self,episodes=5):
        logger.info("ReinforcementLearner: offline training started")
        with Session(self.engine) as session:
            rows=session.query(TradeMetric).order_by(TradeMetric.id.asc()).all()
        if not rows or len(rows)<20:
            logger.warning("Not enough historical trade data."); return None
        trade_pnls=[float(r.pnl) for r in rows]
        wins=sum(1 for r in rows if r.pnl>0); win_rate=wins/len(rows)
        reward=compute_batch_reward(trade_pnls,win_rate)
        logger.info(f"Offline RL reward={reward:.4f}, trades={len(rows)}, win_rate={win_rate:.3f}")
        pnl_tensor=torch.tensor([float(np.mean(trade_pnls)),
                                 float(np.std(trade_pnls)), win_rate, reward],
                                 dtype=torch.float32).unsqueeze(0)
        losses=[]
        for ep in range(episodes):
            probs=self.policy(pnl_tensor)
            dist=Categorical(probs); action=dist.sample()
            loss=self.update_policy([dist.log_prob(action)], reward)
            losses.append(loss); logger.info(f"Episode {ep+1}/{episodes} loss={loss:.6f}")
        self.save_policy(reward)
        return {"reward":reward,"losses":losses,"episodes":episodes}
