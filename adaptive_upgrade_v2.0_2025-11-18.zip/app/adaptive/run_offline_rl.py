"""
CLI runner for offline reinforcement-learning retraining with Plotly charts.
"""

import argparse, os, datetime, plotly.graph_objs as go
from .learner import ReinforcementLearner
from .optimizer import RLHyperOptimizer
from ..monitor.logger import get_logger
logger=get_logger(__name__)

def save_plot(y,title,prefix):
    os.makedirs("data/plots",exist_ok=True)
    ts=datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    fp=f"data/plots/{prefix}_{ts}.html"
    fig=go.Figure(); fig.add_trace(go.Scatter(y=y,mode="lines+markers"))
    fig.update_layout(title=title,xaxis_title="Episode",yaxis_title="Value",template="plotly_white")
    fig.write_html(fp); logger.info(f"Plot saved → {fp}")

def save_bar_plot(x,y,title,prefix):
    os.makedirs("data/plots",exist_ok=True)
    ts=datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    fp=f"data/plots/{prefix}_{ts}.html"
    fig=go.Figure(); fig.add_trace(go.Bar(x=x,y=y))
    fig.update_layout(title=title,template="plotly_white")
    fig.write_html(fp); logger.info(f"Plot saved → {fp}")

def main():
    p=argparse.ArgumentParser(description="Offline RL retrainer")
    p.add_argument("--feature-dim",type=int,default=4)
    p.add_argument("--episodes",type=int,default=10)
    p.add_argument("--tune",action="store_true")
    a=p.parse_args()
    logger.info("=== OFFLINE RL RETRAINING START ===")
    learner=ReinforcementLearner(feature_dim=a.feature_dim); learner.load_latest_policy()
    res=learner.train_from_history(episodes=a.episodes)
    if not res: return
    save_plot(res["losses"],"RL Loss Curve","rl_loss_curve")
    save_plot([res["reward"],res["reward"]],f"RL Reward {res['reward']:.3f}","rl_reward_curve")
    if a.tune:
        opt=RLHyperOptimizer(feature_dim=a.feature_dim)
        bp,bs=opt.optimize(n_trials=5)
        save_bar_plot(list(bp.keys()),list(bp.values()),f"Best Hyperparams (Score={bs:.3f})","rl_hyperparam_summary")
    logger.info("=== OFFLINE RL RETRAINING COMPLETE ===")

if __name__=="__main__": main()
