"""
Hybrid trading strategy engine combining RF, LSTM, and RL policy signals.
Produces unified trading decisions with confidence weighting.
"""

import numpy as np, torch, joblib
from torch.distributions import Categorical
from ..monitor.logger import get_logger
from ..adaptive.model_hub import ModelHub
logger=get_logger(__name__)

class HybridStrategyEngine:
    def __init__(self):
        self.hub=ModelHub()
        self.rf=self.hub.load_model("trade_model","RF")
        self.lstm_state=self.hub.load_model("trade_model","LSTM")
        self.rl_state=self.hub.load_model("adaptive_policy","RLPolicy")
        self.lstm_model=None
        if self.lstm_state:
            from ..ml.trainer import LSTMModel
            self.lstm_model=LSTMModel(input_size=len(self.lstm_state[list(self.lstm_state.keys())[0]].shape)).eval()
            self.lstm_model.load_state_dict(self.lstm_state)
        logger.info("HybridStrategyEngine initialized.")
    def predict(self,features):
        preds=[]
        if self.rf is not None:
            rf_pred=self.rf.predict_proba([features])[0,1]; preds.append(("rf",rf_pred))
        if self.lstm_model is not None:
            tens=torch.tensor(features,dtype=torch.float32).unsqueeze(0).unsqueeze(0)
            out=torch.softmax(self.lstm_model(tens),dim=-1)[0,1].item(); preds.append(("lstm",out))
        if self.rl_state is not None:
            pol=torch.nn.Sequential(torch.nn.Linear(len(features),128),torch.nn.ReLU(),
                                    torch.nn.Linear(128,64),torch.nn.ReLU(),
                                    torch.nn.Linear(64,3),torch.nn.Softmax(dim=-1))
            pol.load_state_dict(self.rl_state); pol.eval()
            probs=pol(torch.tensor(features,dtype=torch.float32)); dist=Categorical(probs)
            action=dist.sample().item()/2.0; preds.append(("rl",action))
        if not preds: return 0
        w={"rf":0.4,"lstm":0.4,"rl":0.2}
        conf=np.sum([w[k]*v for k,v in preds if k in w])
        decision=1 if conf>0.55 else 0 if conf<0.45 else 0.5
        logger.info(f"Hybrid decision={decision} confidence={conf:.3f}")
        return decision
