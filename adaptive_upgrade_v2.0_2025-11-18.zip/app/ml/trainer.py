"""
Trainer module for supervised learning (RandomForest + optional LSTM).
Handles feature generation, evaluation, model saving via ModelHub.
"""

import os, joblib, pandas as pd, numpy as np, torch, torch.nn as nn, torch.optim as optim
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from ..monitor.logger import get_logger
from ..adaptive.model_hub import ModelHub
from .features import make_features

logger=get_logger(__name__)

class LSTMModel(nn.Module):
    def __init__(self,input_size,hidden_size=64,num_layers=2):
        super().__init__()
        self.lstm=nn.LSTM(input_size,hidden_size,num_layers,batch_first=True)
        self.fc=nn.Linear(hidden_size,2)
    def forward(self,x):
        out,_=self.lstm(x); out=self.fc(out[:,-1,:]); return out

class Trainer:
    def __init__(self,model_path="data/models/model.pkl"):
        self.model_path=model_path; self.model=None; self.hub=ModelHub()
    def train(self,df:pd.DataFrame,use_lstm=False):
        if df is None or df.empty:
            logger.error("Trainer: received empty DataFrame."); return None
        logger.info(f"Trainer: received {len(df)} rows.")
        feat_df=make_features(df)
        if feat_df.empty or "close" not in feat_df.columns:
            logger.error("Invalid features."); return None
        feat_df["future_return"]=feat_df["close"].pct_change().shift(-1)
        feat_df["target"]=(feat_df["future_return"]>0).astype(int); feat_df.dropna(inplace=True)
        if len(feat_df)<50:
            logger.warning(f"Too few samples ({len(feat_df)})."); return None
        feature_cols=[c for c in feat_df.columns if c not in("timestamp","target","future_return","open","high","low","close","volume")]
        X,y=feat_df[feature_cols],feat_df["target"]
        Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,shuffle=False)
        if not use_lstm:
            model=RandomForestClassifier(n_estimators=200,max_depth=8,random_state=42)
            model.fit(Xtr,ytr); preds=model.predict(Xte)
            acc=accuracy_score(yte,preds)
            logger.info(f"RF accuracy={acc:.3f} samples={len(X)}")
            joblib.dump(model,self.model_path)
            self.hub.save_model(model,"trade_model","RF",metrics={"accuracy":acc})
            self.model=model; return model
        # ----- LSTM training -----
        Xarr,yarr=X.values.astype(np.float32),y.values.astype(np.int64)
        Xseq=torch.tensor(Xarr).unsqueeze(1); yseq=torch.tensor(yarr)
        model=LSTMModel(input_size=Xseq.shape[-1])
        opt=optim.Adam(model.parameters(),lr=1e-3); loss_fn=nn.CrossEntropyLoss()
        for ep in range(15):
            opt.zero_grad(); out=model(Xseq); loss=loss_fn(out,yseq)
            loss.backward(); opt.step()
            if ep%5==0: logger.info(f"LSTM epoch={ep} loss={loss.item():.5f}")
        torch.save(model.state_dict(),"data/models/lstm_model.pt")
        self.hub.save_model(model,"trade_model","LSTM",metrics={"loss":float(loss.item())})
        self.model=model; return model
    def load(self):
        if os.path.exists(self.model_path):
            self.model=joblib.load(self.model_path)
            logger.info(f"Trainer: model loaded {self.model_path}")
            return self.model
        logger.warning("Trainer: model not found."); return None
